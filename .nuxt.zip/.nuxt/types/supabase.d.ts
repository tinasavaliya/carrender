declare module '#supabase/server' {
  const serverSupabaseClient: typeof import('D:/nuxt/t2/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseClient
  const serverSupabaseServiceRole: typeof import('D:/nuxt/t2/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseServiceRole
  const serverSupabaseUser: typeof import('D:/nuxt/t2/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseUser
}